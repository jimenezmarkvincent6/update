<?php
session_start(); // Start the session
include 'connection.php';

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user information from the session
$fullname = $_SESSION['fullname'];
$role = $_SESSION['role'];
$user_id = $_SESSION['id']; // Get the logged-in user's ID

$sql = "SELECT profile_image FROM admin_staff WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id); // Bind the user ID to the query
$stmt->execute();
$stmt->bind_result($profile_image);
$stmt->fetch();
$stmt->close();

// If the profile image is empty, you can use a default image
if (empty($profile_image)) {
    $profile_image = 'path/to/default-image.jpg'; // Provide the path to a default image
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    
    <title>Student Records</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link href="styles.css" rel="stylesheet" />
    
    <style>

.main-content {
    flex-grow: 1;
    background-color: #F5F5F5;
    padding: 20px;
    margin-left: 250px;
    transition: margin-left 0.3s ease;
}

.overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(8px);
    z-index: 999;
}

.create-panel {
    visibility: hidden;
    opacity: 0;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 90%;
    max-width: 500px;
    background-color: #ffffff;
    padding: 30px;
    border-radius: 12px; /* More rounded corners */
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); /* Softer, larger shadow */
    z-index: 1000;
    transition: opacity 0.3s ease, transform 0.3s ease, visibility 0s 0.3s;
    animation: fadeIn 0.4s ease-out; /* Smooth fade-in animation */
}

/* Make the panel visible when the show class is applied */
.create-panel.show {
    visibility: visible;
    opacity: 1;
    transform: translate(-50%, -50%);
    transition: opacity 0.3s ease, transform 0.3s ease;
}

.create-panel h2 {
    margin-top: 0;
    font-size: 26px;
    color: #333;
    font-weight: 600; /* Bold for better readability */
    text-align: center;
    letter-spacing: 1px; /* Slight letter spacing for style */
}

/* Label styles */
label {
    font-size: 15px;
    margin-right: 10px;
    color: #333;
    font-weight: 500; /* Subtle bold effect */
}

/* Select box styles */
select {
    padding: 12px;
    font-size: 1em;
    border: 2px solid #007bff;
    border-radius: 6px;
    background-color: #fff;
    color: #333;
    width: 100%;
    transition: border-color 0.3s, box-shadow 0.3s;
}

select:hover {
    border-color: #0056b3;
}

select:focus {
    outline: none;
    border-color: #0056b3;
    box-shadow: 0 0 6px rgba(0, 123, 255, 0.5);
}

/* Input field styles */
.create-panel input {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    box-sizing: border-box;
    font-size: 12px;
    transition: border-color 0.3s, box-shadow 0.3s;
}

.create-panel input:hover {
    border-color: #0056b3;
}

.create-panel input:focus {
    border-color: #0056b3;
    box-shadow: 0 0 6px rgba(0, 123, 255, 0.5);
}

/* Submit button styles */
.create-panel button[type="submit"] {
    padding: 12px 24px;
    font-size: 16px;
    cursor: pointer;
    background-color: #007BFF;
    color: white;
    border: none;
    border-radius: 6px;
    transition: background-color 0.3s ease, transform 0.2s;
    width: 100%;
    margin-top: 15px;
}

.create-panel button[type="submit"]:hover {
    background-color: #4A3AFF;
    transform: translateY(-2px); /* Subtle lift effect */
}

/* Close button styles */
.close-btn {
    position: absolute;
    top: 15px;
    right: 15px;
    font-size: 30px;
    cursor: pointer;
    background: none;
    border: none;
    color: #333;
    transition: color 0.3s;
}
.create-btn {
    background-color: #7c3aed;
    color: white;
    font-size: 16px;
    cursor: pointer;
    border: none;
    padding: 12px 24px;
    border-radius: 8px;
    transition: background-color 0.3s, transform 0.2s;
    margin-bottom: 3px;
}
.create-btn:hover {
    background-color: #5a28b8;
    transform: translateY(-2px); /* Subtle lift effect */
}
.close-btn:hover {
    color: #7c3aed; /* Color change on hover */
}

/* Optional - Custom Scrollbar Styling */
.create-panel::-webkit-scrollbar {
    width: 8px;  /* Set the width of the scrollbar */
}

.create-panel::-webkit-scrollbar-thumb {
    background-color: #7c3aed;
    border-radius: 10px;
}

.create-panel::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

.table-container {
    background-color: white;
    border-radius: 10px;
    padding: 20px;
    position: relative;
    overflow-x: auto;
}

.table-container .search-bar-container {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
}

.table-container .search-bar-container .create-btn {
    background-color: #4A3AFF;
    color: white;
    border: none;
    padding: 8px 15px;
    border-radius: 10px;
    cursor: pointer;
    font-size: 14px;
}

.table-container .search-bar-container .search-bar {
    display: flex;
    align-items: center;
    background-color: #f5f5f5;
    padding: 10px;
    border-radius: 20px;
    flex-grow: 1;
}

.table-container .search-bar-container .search-bar input {
    border: none;
    background: none;
    outline: none;
    font-size: 14px;
    flex-grow: 1;
    padding: 1px 2px;
}

.table-container .search-bar-container .search-bar input::placeholder {
    color: #888;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table th, table td {
    padding: 15px;
    text-align: left;
}

table th {
    background-color: #E0E0FF;
}

table tr:nth-child(even) {
    background-color: #F9F9F9;
}

table tr:hover {
    background-color: #F1F1F1;
}

.pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
}

.pagination a {
    color: #4A3AFF;
    text-decoration: none;
    margin: 0 10px;
    font-size: 16px;
}

.pagination .page-number {
    width: 30px;
    height: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #E0E0FF;
    border-radius: 50%;
    margin: 0 5px;
    cursor: pointer;
}

.pagination .page-number.active {
    background-color: #4A3AFF;
    color: white;
}

/* Responsive styles */
@media (max-width: 1024px) {
    .sidebar {
        width: 200px;
    }

    .main-content {
        margin-left: 200px;
    }

    .header .user-info {
        margin-right: 20px;
    }
}

@media (max-width: 768px) {
    .sidebar {
        width: 100%;
        height: auto;
        position: static;
    }

    .main-content {
        margin-left: 0;
        padding: 10px;
    }

    .header .user-info {
        margin-right: 0;
    }

    .table-container {
        padding: 10px;
    }

    .table-container .search-bar-container {
        flex-direction: column;
        align-items: flex-start;
    }

    .table-container .search-bar-container .create-btn {
        margin-right: 0;
        margin-bottom: 10px;
    }

    .table-container .search-bar-container .search-bar {
        width: 100%;
    }

    table th, table td {
        padding: 10px;
        font-size: 14px;
    }

    .pagination a, .pagination .page-number {
        font-size: 14px;
        margin: 0 5px;
    }
}

@media (max-width: 480px) {
    .sidebar {
        width: 100%;
        padding: 10px;
    }

    .sidebar img {
        width: 80px;
        height: 80px;
    }

    .sidebar h1 {
        font-size: 20px;
    }

    .main-content {
        margin-left: 0;
        padding: 10px;
    }
}

    </style>
</head>
<body>

<div class="sidebar">
        <img src="logo/logo/logo.png" alt="Logo">
        <a href="attendance.php">
            <i class="fas fa-calendar-check"></i> Attendance
        </a>
        <a href="student.php">
            <i class="fas fa-user-graduate"></i> Student Records
        </a>
        <a href="parent.php" class="active">
            <i class="fas fa-users"></i> Parent Records
        </a>
        <a href="staff.php">
            <i class="fas fa-user-tie"></i> Admin/Staff Records
        </a>
        <a href="pick_up_records.php">
            <i class="fas fa-clipboard-list"></i> Pick-Up Records
        </a>
        <a href="events.php">
            <i class="fas fa-calendar-alt"></i> Events
        </a>
        <div class="bottom-links">
            <a href="#">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a href="#">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
    <div class="main-content">
    <div class="header">
        <div class="user-info">
            <div class="notification">
                <i class="fas fa-bell"></i>
            </div>
            <div class="vertical-rule"></div>
            <div class="profile">
                <!-- Dynamically display the profile image -->
                <?php if (empty($profile_image)) : ?>
                    <img alt="User profile picture" height="40" src="<?php echo htmlspecialchars($profile_image); ?>" width="40"/>
                <?php else: ?>
                    <img alt="User profile picture" height="40" src="data:image/jpeg;base64,<?php echo base64_encode($profile_image); ?>" width="40"/>
                <?php endif; ?>
                <div class="profile-text">
                    <span><?php echo htmlspecialchars($_SESSION['role']); ?></span><br>
                    <span><?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
                </div>
            </div>
        </div>
    </div>

    <hr/>
        <div class="table-container">
        <div class="search-bar-container">
        <button class="create-btn" id="create-btn">CREATE</button>
<!-- Parent form modal and Authorized Info form -->
 
<div class="overlay" id="overlay">

    <div class="create-panel" id="create-panel">
        <button class="close-btn" id="close-btn">&times;</button>
        <form id="parent-form" action="submit_form.php" method="post" enctype="multipart/form-data">
            <h2>Parent Account Creation</h2>
            <!-- Form Fields -->
            <label for="fullname">Full Name:</label>
            <input type="text" id="fullname" name="fullname" required>
            <label for="contactnumber">Contact Number:</label>
            <input type="tel" id="contactnumber" name="contact_number" required>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
            <label for="parentimage">Parent's Image:</label>
            <input type="file" id="parentimage" name="parent_image" accept="image/*" required>
            <button type="submit">Submit</button>
        </form>
    </div>

    <!-- Authorized Info Form -->
    <div id="authorized-info" class="authorized-info hidden">
        <form id="authorized-form" action="authorized_submit_form.php" method="post" enctype="multipart/form-data">
            <h3>Authorized Pick-Up Person</h3>
            <!-- Form Fields -->
            <label for="authorized_fullname">Full Name:</label>
            <input type="text" id="authorized_fullname" name="authorized_fullname" required>

            <label for="authorized_address">Address:</label>
            <input type="text" id="authorized_address" name="authorized_address" required>

            <label for="authorized_age">Age:</label>
            <input type="number" id="authorized_age" name="authorized_age" required>

            <label for="authorized_image">Upload Authorized Image:</label>
            <input type="file" id="authorized_image" name="authorized_image" accept="image/*" required>

            <button type="submit">Submit Authorized Pick-Up</button>
        </form>
    </div>
</div>
<style>
/* Style for the Authorized Info Form */
#authorized-info {
    display: none; /* Hidden by default */
    background-color: #f8f9fa;
    border-radius: 10px;
    padding: 30px;
    width: 90%;
    max-width: 600px;
    margin: 20px auto;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    font-family: 'Arial', sans-serif;
}

#authorized-info h3 {
    text-align: center;
    color: #333;
    margin-bottom: 20px;
    font-size: 1.5em;
}

/* Style for form labels and inputs */
#authorized-form label {
    font-size: 1.1em;
    margin: 10px 0 5px;
    display: block;
    color: #333;
}

#authorized-form input[type="text"],
#authorized-form input[type="number"],
#authorized-form input[type="file"] {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    font-size: 1em;
}

#authorized-form input[type="file"] {
    padding: 8px;
    background-color: #f1f1f1;
}

#authorized-form button {
    background-color: #007bff;
    color: white;
    font-size: 1.1em;
    padding: 12px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    width: 100%;
    transition: background-color 0.3s ease;
}

#authorized-form button:hover {
    background-color: #0056b3;
}

#authorized-info .hidden {
    display: none;
}

/* Style for input fields when focused */
#authorized-form input[type="text"]:focus,
#authorized-form input[type="number"]:focus,
#authorized-form input[type="file"]:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
}

/* Style for file input label */
#authorized-form input[type="file"] {
    background-color: #f8f9fa;
}

</style>
<script>
// Show the loader
function showLoader() {
    document.getElementById('loader').style.display = 'flex'; // Ensure loader exists
}

// Hide the loader
function hideLoader() {
    document.getElementById('loader').style.display = 'none'; // Ensure loader is hidden properly
}

// Event listener for "CREATE" button
document.getElementById('create-btn').addEventListener('click', function() {
    document.getElementById('overlay').style.display = 'block';
    document.getElementById('create-panel').classList.add('show');
});

// Event listener for "CLOSE" button
document.getElementById('close-btn').addEventListener('click', function() {
    document.getElementById('overlay').style.display = 'none';
    document.getElementById('create-panel').classList.remove('show');
    document.getElementById('parent-form').reset();
});

// Handle Parent Form Submission
document.getElementById('parent-form').addEventListener('submit', async function(event) {
    event.preventDefault(); // Prevent default form submission

    showLoader(); // Show loader while processing

    const formData = new FormData(this); // Collect form data

    try {
        const response = await fetch('submit_form.php', {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json(); // Parse JSON response
        console.log(data); // Add console log for debugging

        if (data.success) {
            // Successfully created the parent account
            alert(data.message || 'Parent account created successfully.');

            // Hide the Parent Form modal
            document.getElementById('create-panel').classList.remove('show');
            document.getElementById('overlay').style.display = 'none';  // Hide overlay

            // Reset the parent form
            this.reset();

            // Show the Authorized Info Form
            const authorizedInfo = document.getElementById('authorized-info');
            const overlay = document.getElementById('overlay');

            // Ensure the form and overlay are visible
            if (authorizedInfo) {
                authorizedInfo.classList.remove('hidden'); // Remove hidden class
                authorizedInfo.style.display = 'block'; // Ensure it's shown correctly
                console.log('Authorized Info Form should be visible now.');
            } else {
                console.error('Authorized Info Form not found!');
            }

            if (overlay) {
                overlay.style.display = 'block'; // Show the overlay
                console.log('Overlay should be visible now.');
            } else {
                console.error('Overlay not found!');
            }

            // Append the Parent ID to the Authorized Info Form as a hidden field
            const parentIdInput = document.createElement('input');
            parentIdInput.type = 'hidden';
            parentIdInput.name = 'parent_id';
            parentIdInput.value = data.parent_id;
            document.getElementById('authorized-form').appendChild(parentIdInput);

            // Scroll to the Authorized Info Form (optional)
            authorizedInfo.scrollIntoView({ behavior: 'smooth' });

        } else {
            alert(data.message || 'An error occurred while creating the parent account.');
            // Redirect to parent PHP page if parent creation failed
            window.location.href = 'parent.php'; // Replace with the correct URL for the parent page
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to create parent account. Please try again.');
        // Redirect to parent PHP page if there was an error in the parent form submission
        window.location.href = 'parent.php'; // Replace with the correct URL for the parent page
    } finally {
        hideLoader(); // Hide loader
    }
});

// Handle Authorized Info Form Submission (Assuming similar structure)
document.getElementById('authorized-form').addEventListener('submit', async function(event) {
    event.preventDefault(); // Prevent default form submission

    showLoader(); // Show loader while processing

    const formData = new FormData(this); // Collect form data

    try {
        const response = await fetch('authorized_submit_form.php', {
            method: 'POST',
            body: formData,
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json(); // Parse JSON response
        console.log(data); // Add console log for debugging

        if (data.success) {
            // Successfully created the authorized info
            alert(data.message || 'Authorized person info saved successfully.');

            // Redirect to the parent PHP page after successful authorized info submission
            window.location.href = 'parent.php'; // Replace with the correct URL for the parent page
        } else {
            alert(data.message || 'An error occurred while saving authorized person info.');
            // Redirect to parent PHP page if the authorized person creation failed
            window.location.href = 'parent.php'; // Replace with the correct URL for the parent page
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to save authorized person info. Please try again.');
        // Redirect to parent PHP page if there was an error in the authorized info submission
        window.location.href = 'parent.php'; // Replace with the correct URL for the parent page
    } finally {
        hideLoader(); // Hide loader
    }
});
</script>



            <div class="search-bar">
            <input type="text" id="search" placeholder="Search..." onkeyup="performSearch(event)">
            </div>
        </div>
        <?php
include 'connection.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Pagination variables
$itemsPerPage = 10; // Items per page
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page from the URL
$currentPage = max(1, $currentPage); // Ensure current page is at least 1
$offset = ($currentPage - 1) * $itemsPerPage; // Offset for SQL query

$userRole = $_SESSION['role']; 

// Prepare the query for pagination
$stmt = $conn->prepare("SELECT id, fullname, contact_number, email, address FROM parent_acc LIMIT ?, ?");
$stmt->bind_param("ii", $offset, $itemsPerPage);
$stmt->execute();
$result = $stmt->get_result();

// Count total records for pagination
$totalResult = $conn->query("SELECT COUNT(*) as total FROM parent_acc");
$totalRow = $totalResult->fetch_assoc();
$totalItems = $totalRow['total'];
$totalPages = ceil($totalItems / $itemsPerPage); // Calculate total pages

// HTML Table
echo '<table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Contact Number</th>
                <th>Email Address</th>
                <th>Address</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>';

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo '<tr>
                <td>' . htmlspecialchars($row['fullname']) . '</td>
                <td>' . htmlspecialchars($row['contact_number']) . '</td>
                <td>' . htmlspecialchars($row['email']) . '</td>
                <td>' . htmlspecialchars($row['address']) . '</td>
                <td>';

        // Check if the user is a super admin
        if ($userRole === 'Super Admin') {
            echo '<i class="fas fa-pen" title="Edit" onclick="location.href=\'edit_staff.php?id=' . $row['id'] . '\'"></i>
                  <i class="fas fa-trash" title="Delete" onclick="location.href=\'delete_staff.php?id=' . $row['id'] . '\'"></i>';
        }

        // Always show the View button
        echo '<i class="fas fa-eye" title="View" data-parent-id="' . $row['id'] . '" onclick="showChildInfo(this.dataset.parentId)"></i>';
        
        echo '</td>
              </tr>';
    }
} else {
    echo '<tr><td colspan="5">No records found</td></tr>';
}

echo '  </tbody>
      </table>';



// Close the database connection
$stmt->close();
$conn->close();
?>
<div id="childInfoModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeModal()">&times;</span>
            <h3>Student Information</h3>
            <div class="student-info">
                
                <div class="button-group">
                    <button class="edit-btn">Edit Info</button>
                </div>
            </div>
        </div>
    </div>


<style>
/* Enhanced Modal Design */
.modal {
    display: none; /* Hidden by default */
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7); /* Darker background for better focus */
}

.modal-content {
    background: #ffffff; /* Clean white background */
    border-radius: 12px;  /* Keeping previous rounded corners */
    padding: 15px; /* Reduced padding */
    max-width: 500px; /* Reduced width for smaller modal */
    width: 85%; /* Slightly smaller width */
    margin: 1% auto 0; /* Move the modal closer to the top by reducing the top margin */
    position: relative;
    animation: slideDown 0.4s ease; /* Smooth slide-down effect */
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
    overflow: hidden; /* Prevent overflowing content */
}

.close-btn {
    font-size: 20px; /* Slightly smaller close button size */
    position: absolute;
    top: 10px;
    right: 15px;
    cursor: pointer;
    color: #333;
    transition: color 0.3s;
}

.close-btn:hover {
    color: #7c3aed; /* Matches button hover color */
}

.modal h3 {
    margin-top: 0;
    font-size: 26px;
    color: #333;
    font-weight: 600; /* Bold for better readability */
    text-align: center;
    letter-spacing: 1px; /* Slight letter spacing for style */
}

.student-info {
    display: flex;
    flex-direction: column;
    gap: 5px; /* Slightly reduced gap for a compact look */
}

.student-photo img {
    width: 50px; /* Slightly smaller photo size */
    height: 50px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #7c3aed; /* Highlighted border */
    top: 20px;
}

.info-field {
    display: flex;
    flex-direction: column;
    gap: 1px;
}

.info-field label {
    font-weight: bold;
    font-size: 12px;
    color: #333;
}

.info-field input {
    padding: 9px; /* Reduced padding for a tighter look */
    border: 1px solid #ddd;
    border-radius: 6px; /* Slightly smaller border radius */
    background-color: #f9f9f9;
    font-size: 12px;
    color: #333;
    outline: none;
    transition: border-color 0.3s;
}

.button-group {
    display: flex;
    justify-content: center;
    margin-top: 15px;
}

button.edit-btn {
    padding: 6px 20px; /* Reduced padding for smaller button */
    border: none;
    border-radius: 8px;
    background-color: #7c3aed;
    color: white;
    font-size: 12px; /* Slightly smaller font size */
    cursor: pointer;
    transition: background-color 0.3s, transform 0.2s;
}

button.edit-btn:hover {
    background-color: #5a28b8;
    transform: translateY(-2px); /* Subtle lift effect */
}

@keyframes slideDown {
    from {
        transform: translateY(-50%);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

@media (max-width: 768px) {
    .modal-content {
        width: 90%; /* Full width on smaller screens */
        padding: 15px;
    }

    .student-photo img {
        width: 70px; /* Smaller photo size on mobile */
        height: 70px;
    }

    button.edit-btn {
        font-size: 14px;
        padding: 6px 18px;
    }
}




    .qr-btn {
        background-color: #10b981;
        color: white;
    }

    .add-btn {
        background-color: #e0e7ff;
        color: #4338ca;
        width: 100%;
        margin-top: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .add-btn i {
        margin-left: 5px;
    }

    #authorized-persons-list {
        margin-bottom: 10px;
    }

    .person {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
        padding: 5px;
        background-color: #f3f4f6;
        border-radius: 4px;
    }

    .person img {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        margin-right: 10px;
    }

    .remove-btn {
        background-color: #ef4444;
        color: white;
        padding: 5px 10px;
        border-radius: 4px;
        cursor: pointer;
    }
    i {
        cursor: pointer; /* Changes the cursor to a pointer */
        margin: 0 5px; /* Optional: Adds spacing between icons */
        transition: transform 0.2s; /* Optional: Adds a hover effect */
    }

    i:hover {
        transform: scale(1.1); /* Optional: Slightly enlarges the icon on hover */
    }

</style>

<script>
function openModal() {
    const modal = document.getElementById('childInfoModal');
    modal.style.display = 'block'; // Set the modal to display
}

function closeModal() {
    const modal = document.getElementById('childInfoModal');
    modal.style.display = 'none'; // Hide the modal
}

// Event listener for outside click
window.onclick = function(event) {
    const modal = document.getElementById('childInfoModal');
    if (event.target === modal) {
        closeModal();
    }
};

// Debug fetch example
function showChildInfo(parentId) {
    console.log('Fetching data for parent ID:', parentId);
    fetch(`child_info.php?parent_id=${parentId}`)
        .then(response => response.text())
        .then(html => {
            const container = document.querySelector('.student-info');
            container.innerHTML = html || '<p>No data available</p>';
            openModal();
        })
        .catch(err => {
            console.error('Error fetching child info:', err);
            alert('Failed to load child information.');
        });
}


</script>


            <div class="pagination" id="pagination"></div>
    <script>
        const totalItems = <?php echo $totalItems; ?>; 
        const itemsPerPage = <?php echo $itemsPerPage; ?>; 
        let currentPage = <?php echo $currentPage; ?>; 

        function renderPagination() {
            const pagination = document.getElementById('pagination');
            pagination.innerHTML = ''; // Clear previous pagination

            const totalPages = Math.ceil(totalItems / itemsPerPage);

            // Previous button
            const prevLink = document.createElement('a');
            prevLink.innerHTML = '«';
            prevLink.className = currentPage === 1 ? 'disabled' : '';
            prevLink.onclick = function() {
                if (currentPage > 1) {
                    currentPage--;
                    updatePage();
                }
            };
            pagination.appendChild(prevLink);

            // Page numbers
            for (let i = 1; i <= totalPages; i++) {
                const pageNumber = document.createElement('div');
                pageNumber.innerHTML = i;
                pageNumber.className = `page-number ${i === currentPage ? 'active' : ''}`;
                pageNumber.onclick = function() {
                    currentPage = i;
                    updatePage();
                };
                pagination.appendChild(pageNumber);
            }

            // Next button
            const nextLink = document.createElement('a');
            nextLink.innerHTML = '»';
            nextLink.className = currentPage === totalPages ? 'disabled' : '';
            nextLink.onclick = function() {
                if (currentPage < totalPages) {
                    currentPage++;
                    updatePage();
                }
            };
            pagination.appendChild(nextLink);
        }

        function updatePage() {
            window.location.href = '?page=' + currentPage; // Redirect to the correct page
        }

        // Initial rendering
        renderPagination();
    </script>
            </div>
        </div>
    </div>

    <script src="script/script.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<style>
/* Loader style */
.loader {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
}

.spinner {
    border: 8px solid #f3f3f3; /* Light grey */
    border-top: 8px solid #3498db; /* Blue */
    border-radius: 50%;
    width: 50px;
    height: 50px;
    animation: spin 2s linear infinite;
}


</style>
<!-- Loading Spinner -->
<div id="loader" class="loader" style="display: none;">
    <div class="spinner"></div>
</div>



</body>
</html>
